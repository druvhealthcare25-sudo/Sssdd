# Trader Portal React UI Demo

This project recreates the supplied screenshots as a responsive React/Vite frontend.

## Run

```bash
npm install
npm run dev
```

Then open the local Vite URL.

## Included

- Login screen
- Home dashboard
- Onboarding with 12 modules
- Locked/unlocked module cards
- Deposit-required modal (demo only)
- Notifications
- Earnings card
- Accounts / Payins / Payouts / Reports placeholder pages
- Responsive mobile bottom navigation

## Important

This is a UI/demo clone. It intentionally does not implement real-money deposits, wallet transfers, credential collection, or payment processing.
