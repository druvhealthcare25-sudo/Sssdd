import React, { useState } from "react";
import {
  Home as HomeIcon, List, CreditCard, ArrowDownToLine, ArrowUpFromLine,
  FileText, Bell, UserRound, Moon, Eye, EyeOff, LockKeyhole,
  CheckCircle2, ChevronRight, Clock3, TrendingUp, X
} from "lucide-react";

const modules = [
  ["Module 1. Introduction & Work Cycle", "Video 06:12 • 3 questions"],
  ["Module 2. Dashboard & Adding Accounts", "Unlocks after module 1"],
  ["Module 3. Forwarder Verification", "Unlocks after module 2"],
  ["Module 4. Receiving Pay-in", "Unlocks after module 3"],
  ["Module 5. Pay-out & the 60-Minute Rule", "Unlocks after module 4"],
  ["Module 6. Payout Receipts", "Unlocks after module 5"],
  ["Module 7. Active Accounts", "Unlocks after module 6"],
  ["Module 8. Settlement USDT", "Unlocks after module 7"],
  ["Module 9. Deposit & Capacity", "Unlocks after module 8"],
  ["Module 10. Scoring & Traffic Distribution", "Unlocks after module 9"],
  ["Module 11. End of Day", "Unlocks after module 10"],
  ["Module 12. Fines & Rules", "Unlocks after module 11"]
];

function App() {
  const [page, setPage] = useState("home");
  const [logged, setLogged] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showDeposit, setShowDeposit] = useState(false);

  if (!logged) {
    return <Login showPassword={showPassword} setShowPassword={setShowPassword} onLogin={() => setLogged(true)} />;
  }

  const nav = [
    ["home", "Home", HomeIcon],
    ["onboarding", "Onboarding", List],
    ["accounts", "Accounts", CreditCard],
    ["payins", "Payins", ArrowDownToLine],
    ["payouts", "Payouts", ArrowUpFromLine],
    ["reports", "Report", FileText]
  ];

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="online"><span /> Online</div>
        <div className="page-title">{page === "onboarding" ? "Onboarding" : page[0].toUpperCase()+page.slice(1)}</div>
        <div className="email">demo@example.com</div>
        <Bell size={22} />
        <UserRound size={22} />
      </header>

      <main className="content">
        {page === "home" && <Home onDeposit={() => setShowDeposit(true)} />}
        {page === "onboarding" && <Onboarding />}
        {["accounts","payins","payouts","reports"].includes(page) && <Placeholder title={page} />}
      </main>

      <nav className="bottom-nav">
        {nav.map(([id, label, Icon]) => (
          <button key={id} className={page === id ? "active" : ""} onClick={() => setPage(id)}>
            <Icon size={25} strokeWidth={1.8}/>
            <span>{label}</span>
          </button>
        ))}
      </nav>

      {showDeposit && <DepositModal close={() => setShowDeposit(false)} />}
    </div>
  );
}

function Login({ onLogin, showPassword, setShowPassword }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-banner">Welcome back to the trader portal</div>
        <div className="login-body">
          <div className="login-heading-row">
            <div>
              <h1>Welcome back!</h1>
              <p>Sign in to your trader account</p>
            </div>
            <button className="icon-btn"><Moon size={20}/></button>
          </div>

          <label>Email</label>
          <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="trader@example.com" />

          <label>Password</label>
          <div className="password-wrap">
            <input type={showPassword ? "text" : "password"} value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password"/>
            <button onClick={()=>setShowPassword(!showPassword)}>{showPassword ? <EyeOff/> : <Eye/>}</button>
          </div>

          <div className="forgot">Forgot password?</div>
          <button className="primary big" onClick={onLogin}>Sign In</button>

          <div className="divider"/>
          <div className="signup">New here? <b>Sign Up</b></div>
          <div className="demo-note">UI demo — no real authentication or payments.</div>
        </div>
      </div>
    </div>
  );
}

function Home({ onDeposit }) {
  return (
    <>
      <section className="hero">
        <div className="progress-pill"><Clock3 size={16}/> ONBOARDING IN PROGRESS</div>
        <div className="progress-line"><span style={{width:"0%"}}/></div>
        <b>0 of 12 modules</b>
        <button className="light-btn">Start module 1</button>
      </section>

      <section className="deposit-card">
        <div className="lock-circle"><LockKeyhole size={30}/></div>
        <h2>Deposit Required</h2>
        <p>Demo gate: add your funding flow here after your compliance and payment setup is complete.</p>
        <button className="white-btn" onClick={onDeposit}>Make Deposit</button>
        <small>Demo minimum: 2000 USDT</small>
      </section>

      <section className="panel">
        <div className="panel-title"><Bell size={25}/> Notifications <a>View all &gt;</a></div>
        <div className="notice blue">Verification pending. Complete Telegram step.</div>
        <div className="notice yellow">Deposit is required before any trading operations.</div>
        <div className="notice green">Your account UI preview is ready.</div>
      </section>

      <section className="panel earnings">
        <div className="panel-title"><TrendingUp size={24}/> Earnings</div>
        <div className="tabs"><b>Tdy</b><span>7D</span><span>30D</span><span>Custom</span></div>
        <small>Today</small>
        <div className="amount">$0.00</div>
        <div className="stat-row"><div>Transactions<br/><b>0</b></div><div>Success Rate<br/><b>0%</b></div></div>
      </section>
    </>
  );
}

function Onboarding() {
  return (
    <>
      <section className="hero">
        <div className="progress-pill"><Clock3 size={16}/> ONBOARDING IN PROGRESS</div>
        <div className="progress-line"><span style={{width:"0%"}}/></div>
        <b>0 of 12 modules</b>
        <button className="light-btn">Start module 1</button>
      </section>
      <h1 className="onboard-title">Onboarding</h1>
      <p className="muted">12 modules, each with a short test.<br/>Modules unlock one by one — about 80 min of work.</p>

      <ModuleGroup title="BASICS" subtitle="how the platform and support work" range="0/3 modules">
        {modules.slice(0,3).map((m,i)=><Module key={i} i={i} title={m[0]} sub={m[1]} unlocked={i===0}/>)}
      </ModuleGroup>
      <ModuleGroup title="DAILY OPERATIONS" subtitle="the money flow you run every shift" range="0/4 modules">
        {modules.slice(3,7).map((m,i)=><Module key={i} i={i+3} title={m[0]} sub={m[1]} />)}
      </ModuleGroup>
      <ModuleGroup title="MONEY, SCORING & RULES" subtitle="what you earn and what it costs to break rules" range="0/5 modules">
        {modules.slice(7).map((m,i)=><Module key={i} i={i+7} title={m[0]} sub={m[1]} />)}
      </ModuleGroup>
    </>
  );
}

function ModuleGroup({title, subtitle, range, children}) {
  return <section className="module-group">
    <div className="group-head"><div><b>{title}</b><small>{subtitle}</small></div><span>{range}</span></div>
    {children}
  </section>
}

function Module({i,title,sub,unlocked}) {
  return <div className={"module "+(unlocked ? "unlocked":"locked")}>
    <div className="num">{i+1}</div>
    <div className="module-text"><b>{title}</b><small>{sub}</small></div>
    {unlocked ? <button className="start-btn">Start</button> : <LockKeyhole size={21}/>}
  </div>
}

function Placeholder({title}) {
  return <div className="placeholder">
    <h1>{title[0].toUpperCase()+title.slice(1)}</h1>
    <p>This is a frontend placeholder page. Connect your own backend/API here.</p>
  </div>
}

function DepositModal({close}) {
  return <div className="modal-backdrop" onClick={close}>
    <div className="modal" onClick={e=>e.stopPropagation()}>
      <button className="modal-x" onClick={close}><X/></button>
      <h2>Deposit Required</h2>
      <p>Functionality is unavailable until the first demo deposit step.</p>
      <p className="muted">This clone does not process or request real funds.</p>
      <button className="primary big" onClick={close}>Close Demo</button>
    </div>
  </div>
}

export default App;